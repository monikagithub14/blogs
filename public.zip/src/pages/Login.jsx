import React, { useState } from "react";
import { FiUser, FiPhone } from "react-icons/fi";
import { useLocation, useNavigate } from "react-router-dom"; // Assuming you use react-router
import { useDirectLoginMutation } from "../Redux/API/UsersAPI";
import { useAddToCartMutation } from "../Redux/API/CartAPI";

const Login = () => {
  // 1. State for form inputs
  const [credentials, setCredentials] = useState({
    name: "",
    phone: "",
  });

  // 2. State for UI feedback
  const [errorMsg, setErrorMsg] = useState("");

  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/";

  // 3. API Hook
  const [directLogin, { isLoading }] = useDirectLoginMutation();
  const [addToCart] = useAddToCartMutation();

  // Handle Input Change
  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
    // Clear error when user types
    if (errorMsg) setErrorMsg("");
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!credentials.name || !credentials.phone) {
      setErrorMsg("Please fill in all fields");
      return;
    }

    try {
      // 1. Perform Login
      await directLogin(credentials).unwrap();

      // 2. Check if user had a flower waiting to be added
      const pendingItem = localStorage.getItem("pendingCartItem");

      if (pendingItem) {
        const { productId, quantity } = JSON.parse(pendingItem);
        try {
          // 3. Execute the deferred add-to-cart call
          await addToCart({ productId, quantity }).unwrap();
          localStorage.removeItem("pendingCartItem"); // Success: clear storage

          // If you want to go specifically to cart after adding:
          navigate("/cart");
          // return;
        } catch (cartErr) {
          console.error("Auto-add to cart failed:", cartErr);
        }
      }

      navigate(from, { replace: true });
      // navigate(-1);
    } catch (err) {
      setErrorMsg(err?.data?.message || "Login failed. Please try again.");
    }
  };
  return (
    <div
      className="min-h-screen flex items-center justify-center bg-cover bg-center p-4"
      style={{
        backgroundImage: "url('images/About/loginBg.jpeg')",
      }}
    >
      <div className="w-full max-w-[1250px] min-h-[600px] flex flex-col lg:flex-row items-center justify-center lg:justify-between gap-10">
        {/* LEFT GLASS LOGIN CARD */}
        <div
          className="w-full max-w-md lg:w-[450px] min-h-[520px]
                bg-white/5 backdrop-blur-md
                border border-white/10
                rounded-2xl px-8 py-10 lg:px-10 text-white
                shadow-[0_10px_50px_rgba(0,0,0,0.3)] flex flex-col"
        >
          {/* LOGO */}
          <div className="flex flex-col items-center mb-6">
            <img
              src="/images/logo.png"
              alt="Aditi Logo"
              className="w-10 mb-2 opacity-90"
            />
          </div>

          <h2 className="text-center font-amandine text-lg mb-8 opacity-90 mt-4 lg:mt-12">
            Sign In
          </h2>

          <form onSubmit={handleLogin} className="flex-1 flex flex-col">
            {/* INPUT 1: NAME */}
            <div className="flex font-sans items-center border-b border-white/30 mb-6 pb-2 transition-colors focus-within:border-white/80">
              <FiUser className="mr-3 text-white/70 text-lg" />
              <input
                type="text"
                name="name"
                value={credentials.name}
                onChange={handleChange}
                placeholder="Enter Your Name"
                className="w-full bg-transparent outline-none
                                placeholder-white/60 text-sm text-white"
              />
            </div>

            {/* INPUT 2: MOBILE */}
            <div className="flex font-sans items-center border-b border-white/30 mb-2 pb-2 transition-colors focus-within:border-white/80">
              <FiPhone className="mr-3 text-white/70 text-lg" />
              <input
                type="tel"
                name="phone"
                value={credentials.phone}
                onChange={handleChange}
                placeholder="Mobile No"
                className="w-full bg-transparent outline-none
                                placeholder-white/60 text-sm text-white"
              />
            </div>

            {/* Error Message Display */}
            <div className="h-6 mb-8 mt-2">
              {errorMsg && (
                <p className="text-red-300 text-xs text-center font-sans animate-pulse">
                  {errorMsg}
                </p>
              )}
            </div>

            {/* LOGIN BUTTON */}
            <button
              type="submit"
              disabled={isLoading}
              className={`px-12 py-3 font-sans rounded-full mx-auto flex
                            border border-white/30 bg-white/10
                            shadow-inner shadow-black/40
                            hover:bg-white/20 transition mt-auto mb-8
                            ${
                              isLoading ? "opacity-50 cursor-not-allowed" : ""
                            }`}
            >
              {isLoading ? "Logging in..." : "Login"}
            </button>
          </form>
        </div>

        {/* RIGHT IMAGE - Hidden on mobile, Visible on Desktop (lg) */}
        <div className="hidden lg:flex flex-1 justify-center items-center">
          <img
            src="images/About/allperfumes.png"
            alt="Perfume"
            className="max-w-full lg:max-w-[790px] h-auto object-contain
                        drop-shadow-[0_40px_60px_rgba(0,0,0,0.8)]"
          />
        </div>
      </div>
    </div>
  );
};

export default Login;
